## Robótica Móvel

### Trabalho Prático 2 – Planejamento e Navegação


Valor: 14,0 pontos
Entrega: 08/05/2024

Nomes:
Felippe Veloso Marinho, 2021072260
João Vitor Mateus Silva, 2020425801